This modules uses `ionRangeSlider <http://ionden.com/a/plugins/ion.rangeSlider/index.html>`_
library that shows a slider with two points to set the maximum and minimum values. Also it's
compatible with old browsers.
