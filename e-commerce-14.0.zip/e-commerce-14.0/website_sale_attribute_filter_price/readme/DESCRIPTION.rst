This module adds a price filter in the website
