#. Go to shop
#. Drop down 'Customize' menu
#. Enable 'Price Filter' option

Theming
~~~~~~~

CSS Classes:

- ``price_filter_main`` > The main container (slider + inputs + button)

HTML ID's:

- ``filter_price_slider`` > The Slider
- ``price_range_min_value`` > The input for minimum price
- ``price_range_max_value`` > The input for maximum price
- ``price_slider_form`` > The submit button
