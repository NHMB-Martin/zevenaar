#. Go to shop
#. Use the slider to select prices
#. Click 'Go'
