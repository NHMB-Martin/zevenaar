This module allows to logged users to checkout with no payment step. At the
end of the checkout proccess the quotation is sent to the user email address
and set to *Qoutation Sent* state.
