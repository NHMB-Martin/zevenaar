To configure this module, you need to:

#. Go to *Sales > Customers > Sales and Purchases > Sale*
#. Set on *Skip Website Checkout Payment* so this partner will override the
   payment step on website sales.
