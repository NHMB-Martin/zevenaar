To use this module, you need to:

#. Go to *Website > shop* and perform a checkout.
