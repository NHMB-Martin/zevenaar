from . import website
from . import res_partner
from . import res_config_settings
