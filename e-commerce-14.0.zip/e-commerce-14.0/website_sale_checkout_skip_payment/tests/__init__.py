from . import test_checkout_skip_payment
