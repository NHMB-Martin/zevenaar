Go to `Website > Configuration > eCommerce > Shipping Methods Groups`
and set up your groups.
