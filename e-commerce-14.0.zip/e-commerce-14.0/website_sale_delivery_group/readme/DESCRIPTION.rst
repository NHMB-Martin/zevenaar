Provides a way to group shipping methods on the website checkout page.

.. image:: ../static/description/website_sale_delivery_group_1.png

.. image:: ../static/description/website_sale_delivery_group_2.png
