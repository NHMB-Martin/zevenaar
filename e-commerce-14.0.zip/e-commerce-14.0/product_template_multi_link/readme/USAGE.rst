* To mass edit or create links between products templates, Go to
  Sale > Configuration > Products > Product Links

.. figure:: /product_template_multi_link/static/description/product_template_link_tree.png
   :width: 800 px

A kanban view is also available

.. figure:: /product_template_multi_link/static/description/product_template_link_kanban.png
   :width: 800 px


* You can manage links by product, Go to Sales > Sales > Products and select
  a product

.. figure:: /product_template_multi_link/static/description/product_template_form.png
   :width: 800 px

* You can so add new item, line by line, via an editable tree view

.. figure:: /product_template_multi_link/static/description/product_template_link_tree_edit.png
   :width: 800 px


.. image:: https://odoo-community.org/website/image/ir.attachment/5784_f2813bd/datas
   :alt: Try me on Runbot
   :target: https://runbot.odoo-community.org/runbot/113/14.0
