#. Go to *Settings > General Settings > Website* and active the option *Multiple Sales
   Prices per Product* with the second option, for use the pricelists.
