This module extends the functionality of website sale module to allow to
display the minimal price in '/shop' view  when product has distinct variants
price and set order by minimal price in product's view.
