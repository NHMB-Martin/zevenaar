Extends `product_template_multi_link` to link product variants.
