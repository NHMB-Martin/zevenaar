Create a link as you would do with `product_template_multi_link`
and after setting a template, set a variant for that template.
