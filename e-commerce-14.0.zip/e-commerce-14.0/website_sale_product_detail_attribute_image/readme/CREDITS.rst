This module has free images from https://www.iconfinder.com/
