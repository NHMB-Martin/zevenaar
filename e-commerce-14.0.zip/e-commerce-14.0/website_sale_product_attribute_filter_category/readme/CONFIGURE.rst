To configure this module, you need to:

* Go to 'Website > Configuration > Attribute Categories' and create one.
  You can select if you want display it folded or unfolded in website.
* Go to 'Website > Configuration > Attributes' and create one or more with
  this category.
* Go to 'Website > Configuration > Attribute Values' and create more than one
  value for this attribute.
* Go to 'Website > Products > Products' and create a product with this
  attribute and assign it an attribute value.
