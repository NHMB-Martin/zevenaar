#. Go to Website Shop.
#. Active filter by attributes in "Customize" option in top menu.
#. Now you can see product attributes filter grouped by categories.
