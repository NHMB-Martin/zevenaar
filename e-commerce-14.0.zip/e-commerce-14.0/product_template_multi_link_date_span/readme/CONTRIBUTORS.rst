* Thierry Ducrest <thierry.ducrest@camptocamp.com>
* Trobz
    * Dung Tran <dungtd@trobz.com>
* Simone Orsi <simahawk@gmail.com>
