This module adds the possibility to set a start and end date on the links.
So links can be activated only for a certain period of time.
