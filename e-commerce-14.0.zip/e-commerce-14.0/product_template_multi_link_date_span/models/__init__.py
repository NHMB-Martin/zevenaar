from . import product_template_link_type
from . import product_template_link
