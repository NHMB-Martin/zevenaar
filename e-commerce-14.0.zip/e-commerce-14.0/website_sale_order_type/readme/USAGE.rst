#. In the backend (Sales -> Customers) set a sale order type in any contact;
#. Log in with the associated user in the e-commerce website and buy a product;
#. Check that the created sale oder has the same sale order type that has been set in the contact.
