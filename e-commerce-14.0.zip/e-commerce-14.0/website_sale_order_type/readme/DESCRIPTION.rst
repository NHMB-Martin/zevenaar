This module allows `sale_order_type <https://github.com/OCA/sale-workflow/tree/14.0/sale_order_type>`__ to work with website_sale.

This module is useful for users having a sale order type defined in their Partner form:
when these users buy a product in the e-commerce, the sale order generated will have the same sale order type that is defined in their Partner form.

Note that the sale order type is defined contact by contact and not at Company level.
