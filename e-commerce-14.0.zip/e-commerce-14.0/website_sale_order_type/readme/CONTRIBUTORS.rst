* Simone Rubino <simone.rubino@agilebg.com>

* `Tecnativa <https://www.tecnativa.com>`_:

    * João Marques
